﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FileWebApp.Models;

namespace FileWebApp.Data
{
    public class FileWebAppContext : DbContext
    {
        public FileWebAppContext (DbContextOptions<FileWebAppContext> options)
            : base(options)
        {
        }

        public DbSet<FileWebApp.Models.FileDetails> FileDetails { get; set; }
    }
}
