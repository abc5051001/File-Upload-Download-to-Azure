﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using FileWebApp.Models;
using System.Security.Principal;

namespace FileWebApp.Services
{
    public class StorageService : IStorageService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly IConfiguration _configuration;

        public StorageService(
            BlobServiceClient blobServiceClient,
            IConfiguration configuration)
        {
            _blobServiceClient = blobServiceClient;
            _configuration = configuration;
        }

        public void Upload(IFormFile formFile)
        {
            var containerName = _configuration.GetSection("Storage:ContainerName").Value;
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(formFile.FileName);
            using var stream = formFile.OpenReadStream();
            blobClient.Upload(stream, true);
        }
        public FileDetails Extract(IFormFile formFile)
        {
            string fileName = formFile.FileName;
            FileInfo oFileInfo = new FileInfo(fileName);
            FileDetails newfile = new FileDetails();
            newfile.FileName = oFileInfo.Name;
            newfile.FilePath = "Azure Blobs: files";
            newfile.FileSize = oFileInfo.Length.ToString();
            newfile.FileCreationDate = oFileInfo.CreationTime;
            // HttpContext.Current.User.Identity.Name;
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            newfile.FileUploadedBy = userName;
            newfile.Id = formFile.FileName.GetHashCode();
            DateTime now = DateTime.Now;
            newfile.RecordCreationDate = now;
            newfile.FileType = oFileInfo.Extension;
            newfile.Status = "New";
            //string ans = "";
            //if (oFileInfo != null || oFileInfo.Length == 0)
            //{
            //    ans += "My File's Name: \"" + oFileInfo.Name + "\"";
            //    // For calculating the size of files it holds.
            //    ans += "myFile filepath: " + oFileInfo.DirectoryName;
            //    ans += "myFile total Size: " + oFileInfo.Length.ToString();
            //}
            //DateTime dtCreationTime = oFileInfo.CreationTime;
            //ans += "Date and Time File Created: " + dtCreationTime.ToString();
            //ans += "myFile Extension: " + oFileInfo.Extension;
            return (newfile);
        }
    }
}
