﻿using Microsoft.AspNetCore.Http;
using FileWebApp.Models;
namespace FileWebApp.Services
{
    public interface IStorageService
    {
        void Upload(IFormFile formFile);

        FileDetails Extract(IFormFile formFile);
    }
}
