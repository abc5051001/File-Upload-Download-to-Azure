﻿namespace FileWebApp.Models
{
    public class FileDetails
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string? Status { get; set; }
        public string? FileType { get; set; }
        public string? FilePath { get; set; }
        public string? FileSize { get; set; }
        public string? FileOwner { get; set; }

        public DateTime? FileCreationDate  { get; set; }
        public DateTime? FileModifiedDate { get; set; }
        public string? FileUploadedBy { get; set; }
        public DateTime? RecordCreationDate { get; set; }
        public DateTime? RecordModifiedDate { get; set; }
        public byte[]? FileContents { get; set; }
        public FileDetails()
        {

        }

    }
}
